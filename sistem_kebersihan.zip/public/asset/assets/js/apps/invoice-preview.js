$('.action-print').on('click', function(event) {
  event.preventDefault();
  /* Act on the event */
  window.print();
});